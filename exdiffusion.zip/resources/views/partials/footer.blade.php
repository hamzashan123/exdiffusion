﻿
  <footer class="footer">
      <img src="{{asset('img/logo.png')}}" class="logoFooter">
  </footer>
