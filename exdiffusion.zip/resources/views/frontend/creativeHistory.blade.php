﻿@extends('layouts.app')

@section('content')
<h2 class="text-white">Coming Soon</h2>
@endsection('content')