﻿
  <footer class="footer">
      <img src="<?php echo e(asset('img/logo.png')); ?>" class="logoFooter">
  </footer>
<?php /**PATH C:\xampp\htdocs\ConyProject\ConyStableDiffusion\resources\views/partials/footer.blade.php ENDPATH**/ ?>