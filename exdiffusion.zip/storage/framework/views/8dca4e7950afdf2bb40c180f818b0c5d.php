﻿<header class="header">
   
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <a href="/" class="logoAnchor">
          <img src="<?php echo e(asset('img/logo.png')); ?>" class="HeaderLogo">
        </a>

        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a href="#" class="nav-link px-3 text-light-grey">Home</a></li>
          <li><a href="#" class="nav-link px-3 text-light-grey">Playground</a></li>
          <li><a href="#" class="nav-link px-3 text-light-grey">Published Creations</a></li>
          <li><a href="#" class="nav-link px-3 text-light-grey">Creative History</a></li>
          <li><a href="#" class="nav-link px-3 text-light-grey">Upload Models</a></li>
          <li><a href="#" class="nav-link px-3 text-light-grey">Invitation Request</a></li>
          <li><a href="#" class="nav-link px-3 text-light-grey" id="restart_server">Restart Server</a></li>
          
        </ul>

        
      </div>
  
  </header><?php /**PATH C:\xampp\htdocs\ConyExdiffusion\exdiffusion\resources\views/partials/header.blade.php ENDPATH**/ ?>